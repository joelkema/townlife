import and from "./and";
import when from "./when";
import or from "./or";
import compose from "./compose";
import not from "./not";
import { pipe } from "./pipe";

export { and, when, compose, or, pipe, not };
